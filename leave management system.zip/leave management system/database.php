<?php
session_start();
$conn = mysqli_connect("localhost","root","","leave_management_system");

?>