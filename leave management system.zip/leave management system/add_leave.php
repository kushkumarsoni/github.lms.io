<?php
require('header.php');
if(isset($_POST['submit'])){
		
		$leave_id = mysqli_real_escape_string($conn,$_POST['leave_id']);
		$emp_id = $_SESSION['USER_ID'];
		$leave_from = mysqli_real_escape_string($conn,$_POST['leave_from']);
		$leave_to = mysqli_real_escape_string($conn,$_POST['leave_to']);
		$leave_description = mysqli_real_escape_string($conn,$_POST['leave_description']);

		$sql = "insert into `leave`(leave_id,emp_id,leave_from,leave_to,leave_description,leave_status) values('$leave_id','$emp_id','$leave_from','$leave_to','$leave_description','1')";
		$res = mysqli_query($conn,$sql);
		header("location:leave.php");
		die();
	}
?>
<div class="content pb-0">
            <div class="animated fadeIn">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header"><strong>Leave</strong><small> Form</small></div>
                        <div class="card-body card-block">
                           <form method="post">
                           		<div class="form-group">
									<label class="form-control-label">Leave Type</label>	
									<select name="leave_id" class="form-control" required>
										<option value="">Select Leave Type</option>
											<?php

												$res =mysqli_query ($conn,"select * from leave_type order by leave_type desc"); 
											    while($row = mysqli_fetch_assoc($res)):?>
													<option value="<?php echo $row['leave_id']; ?>"><?php echo $row['leave_type']; ?></option>
											<?php endwhile; ?>
									</select>
								</div>
								<div class="form-group">
									<label for="leave_from" class=" form-control-label">Leave From</label>
									<input type="date" name="leave_from" class="form-control" required>
								</div>

								<div class="form-group">
									<label for="leave_to" class=" form-control-label">Leave To</label>
									<input type="date" name="leave_to"class="form-control" required>
								</div>

								<div class="form-group">
									<label for="leave_description" class=" form-control-label">Leave Description</label>
									<input type="text" name="leave_description" placeholder="Enter Leave Description" class="form-control" required>
								</div>
							   <button  type="submit" name ="submit" class="btn btn-lg btn-info btn-block">
							   <span id="payment-button-amount">Submit</span>
							   </button>
							  </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
                  
<?php
require('footer.php');
?>