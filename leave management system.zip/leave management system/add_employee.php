<?php
require('header.php');
$empname = "";
$email ="";
$mobile ="";
$id ="";
$password = "";
$dept_id ="";
$address = "";
$birthday = "";
if(isset($_GET['id'])){
		$id = mysqli_real_escape_string($conn,$_GET['id']);
		// it is for user when the user logged in 
		if($_SESSION['ROLE']==2 && $_SESSION['USER_ID']!=$id)
		{
			die("<h1 align='center' style='color:red;'>Access denied</h1>");
		}
		// end user 
		$res = mysqli_query($conn,"select * from employee where emp_id='$id'");
		$row = mysqli_fetch_assoc($res);
		$empname = $row['empname'];
		$email = $row['email'];
		$mobile = $row['mobile'];
		$password = $row['password'];
		$dept_id = $row['dept_id'];
		$address = $row['address'];
		$birthday = $row['birthday'];
}

if(isset($_POST['submit'])){
		
		$empname = mysqli_real_escape_string($conn,$_POST['employee']);
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$mobile = mysqli_real_escape_string($conn,$_POST['mobile']);
		$password = mysqli_real_escape_string($conn,$_POST['password']);
		$dept_id = mysqli_real_escape_string($conn,$_POST['dept_id']);
		$address = mysqli_real_escape_string($conn,$_POST['address']);
		$birthday = mysqli_real_escape_string($conn,$_POST['birthday']);

		if($id>0){
			$sql= "update employee set empname ='$empname',email = '$email',mobile = '$mobile',password = '$password',dept_id ='$dept_id',address ='$address',birthday ='$birthday' where emp_id='$id'"; 
		}
		else{
			$sql = "insert into employee(empname,email,mobile,password,dept_id,address,birthday,role) values('$empname','$email','$mobile','$password','$dept_id','$address','$birthday','2')";
		}
		$res = mysqli_query($conn,$sql);
		header("location:employee.php");
		die();
	}
?>
<div class="content pb-0">
            <div class="animated fadeIn">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header"><strong>Employee</strong><small> Form</small></div>
                        <div class="card-body card-block">
                           <form method="post">
							   <div class="form-group">
									<label for="employee" class=" form-control-label">Employee Name</label>
									<input type="text" value="<?php echo $empname; ?>" name="employee" placeholder="Enter Employee Name" class="form-control" required></div>

								<div class="form-group">
									<label for="email" class=" form-control-label">Email</label>
									<input type="text" value="<?php echo $email; ?>" name="email" placeholder="Enter Employee Email" class="form-control" required></div>

								<div class="form-group">
									<label for="mobile" class=" form-control-label">Mobile</label>
									<input type="text" value="<?php echo $mobile; ?>" name="mobile" placeholder="Enter Mobile Number" class="form-control" required></div>

								<div class="form-group">
									<label for="password" class=" form-control-label">Password</label>
									<input type="password" value="<?php echo $password; ?>" name="password" placeholder="Enter Password" class="form-control" required></div>

								<div class="form-group">
									<label class="form-control-label">Department</label>	
									<select name="dept_id" class="form-control" required>
										<option value="">Select Department</option>
											<?php

												$res =mysqli_query ($conn,"select * from department order by department desc"); 
											    while($row = mysqli_fetch_assoc($res)):?>
												if($dept_id==$row['dept_id'])
												{
													 <option selected="selected" value="<?php echo $row['dept_id']; ?>" ><?php echo $row['department']; ?></option>
												}
												else
												{
												 <option value="<?php echo $row['dept_id']; ?>"><?php echo $row['department']; ?></option>
											 	}
											<?php endwhile; ?>
									</select>
								</div>

								<div class="form-group">
									<label for="address" class=" form-control-label">Address</label>
									<input type="text" value="<?php echo $address; ?>" name="address" placeholder="Enter Address" class="form-control" required></div>

								<div class="form-group">
									<label for="birthday" class=" form-control-label">Birthday</label>
									<input type="date" value="<?php echo $birthday; ?>" name="birthday" placeholder="Enter Birthday" class="form-control" required></div>
								<?php if($_SESSION['ROLE']==1) {?>
							   <button  type="submit" name ="submit" class="btn btn-lg btn-info btn-block">
							   <span id="payment-button-amount">Submit</span>
							   </button>
							<?php } ?>
							  </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
                  
<?php
require('footer.php');
?>